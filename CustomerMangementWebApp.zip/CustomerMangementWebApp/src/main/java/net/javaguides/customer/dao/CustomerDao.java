package net.javaguides.customer.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import net.javaguides.customer.model.Customer;

public class CustomerDao {
	
	String jdbcURL = "jdbc:mysql://localhost:3306/demo?useSSL=false";
	String jdbcUsername="root";
	String jdbcPassword="2282001";
	
	
	private static final String Insert_customer_SQL = "Insert into customer"+ "(firstName, lastName, Address, City, State, Email, Phone) VALUES "+"(?,?,?,?,?,?,?);";
	
	private static final String Select_all_customers_by_email ="select firstName, lastName, Address, City, State, Email, Phone from customer where phone=? ";
	private static final String Select_all_customers = "select * from customer";
	private static final String Delete_customer = "delete from customer where phone=?;";
	private static final String Update_customer = "update customer set firstName=?, lastName=?,  Address=?,City=?, State=?, Email=?, Phone=?";

	//create new customer//create new customer or insert customer, update customer, select customer by phone, select customer, delete customer
	protected Connection getConnection() {
		Connection con = null;
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(jdbcURL,jdbcUsername, jdbcPassword);
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
	
	//create or insert customer
public void insertCustomer(Customer customer ) throws SQLException {
		
		try (Connection con = getConnection();
				
				PreparedStatement pstmt = con.prepareStatement(Insert_customer_SQL)){
			pstmt.setString(1,customer.getFirstName());
			pstmt.setString(2, customer.getLastName());
			pstmt.setString(3, customer.getAddress());
			pstmt.setString(4, customer.getCity());
			pstmt.setString(5, customer.getState());
			pstmt.setString(6, customer.getEmail());
			pstmt.setDouble(7, customer.getPhone());
			pstmt.executeUpdate();
	   }catch(Exception e)
		{
		   e.printStackTrace();
		}
	}

//update customer
public boolean updateCustomer(Customer customer) throws SQLException
{
	boolean rowUpdated;
	try(Connection con = getConnection();
			PreparedStatement stmt = con.prepareStatement(Update_customer);){
		
		stmt.setString(1,customer.getFirstName());
		stmt.setString(2, customer.getLastName());
		stmt.setString(3, customer.getAddress());
		stmt.setString(4, customer.getCity());
		stmt.setString(5, customer.getState());
		stmt.setString(6, customer.getEmail());
		stmt.setDouble(7, customer.getPhone());
		rowUpdated=stmt.executeUpdate()>0;
		
	}
	return rowUpdated;		
   }

public Customer selectCustomer(String email ) throws SQLException
{
	Customer customer = null;
	try(Connection con=getConnection();
			PreparedStatement pstmt = con.prepareStatement(Select_all_customers_by_email);){
		pstmt.setString(1, email);
		System.out.println(pstmt);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			String firstName = rs.getString("firstName");
			String lastName = rs.getString("lastName");
			String Address = rs.getString("Address");
			String City = rs.getString("City");
			String State = rs.getString("State");
			String Email = rs.getString("Email");
			double Phone = rs.getDouble("Phone");
			customer = new Customer(firstName, lastName, Address, City,State, Email,Phone);
		}
	}catch (SQLException e) {
		e.printStackTrace();
	}
	return customer;
	
} 
//select all customers
	public List<Customer> selectAllCustomer() throws SQLException
	{
		List<Customer> customers = new ArrayList<>();
		try(Connection con=getConnection();
				PreparedStatement pstmt = con.prepareStatement(Select_all_customers_by_email);){
			
			System.out.println(pstmt);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				String firstName = rs.getString("firstName");
				String lastName = rs.getString("lastName");
				String Address = rs.getString("Address");
				String City = rs.getString("City");
				String State = rs.getString("State");
				String Email = rs.getString("Email");
				double Phone = rs.getDouble("Phone");
				customers.add(new Customer(firstName, lastName, Address, City,State, Email,Phone));
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return customers;
		
	}
	
	public boolean deleteCustomer(String email) throws SQLException{
		boolean rowDeleted;
		try(Connection con = getConnection();
		PreparedStatement stmt = con.prepareStatement(Delete_customer);){
			stmt.setString(1, email);
			rowDeleted = stmt.executeUpdate()>0;
		}
		return rowDeleted;
	}
	

}
