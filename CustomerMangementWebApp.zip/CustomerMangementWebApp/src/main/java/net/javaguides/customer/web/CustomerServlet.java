package net.javaguides.customer.web;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.javaguides.customer.dao.CustomerDao;
import net.javaguides.customer.model.Customer;

/**
 * Servlet implementation class CustomerServlet
 */
@WebServlet("/")
public class CustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private CustomerDao customerDao;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CustomerServlet() {

		this.customerDao = new CustomerDao();
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();
		switch (action) {
		case "/new":
			showNewForm ( request, response);
			break;
		case "/insert":
			try {
				insertCustomer(request, response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/delete":
			try {
				deleteCustomer( request,  response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/edit":
			try {
				showEditForm( request,  response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/update":
			try {
				updateCustomer( request,  response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		default:
			try {
				listCustomer( request,  response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;

		}	
		
	}
	private void listCustomer(HttpServletRequest request, HttpServletResponse response)
		    throws SQLException, IOException, ServletException {
		        List<Customer> listCustomer=customerDao.selectAllCustomer();
		        request.setAttribute("listCustomer",listCustomer);
		        RequestDispatcher dispatcher = request.getRequestDispatcher("customer-list.jsp");
		        dispatcher.forward(request, response);
		    }
	private void showNewForm (HttpServletRequest request, HttpServletResponse response)
			 throws ServletException , IOException{
				RequestDispatcher dispatcher = request.getRequestDispatcher("customer-form.jsp");
				dispatcher.forward(request, response);
			}
	private void insertCustomer(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException{
				String firstName = request.getParameter("firstName");
				String lastName = request.getParameter("lastName");
				String Address = request.getParameter("Address");
				String City = request.getParameter("City");
				String State = request.getParameter("State");
				String Email = request.getParameter("Email");
				
				Customer newCustomer = new Customer(firstName, lastName, Address, City,State, Email);
				customerDao.insertCustomer(newCustomer);
				response.sendRedirect("list");
			}
     
	private void deleteCustomer(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException{
				String email = (request.getParameter("email"));
				customerDao.deleteCustomer((String)email);
				response.sendRedirect("list");
				
			}
	private void showEditForm(HttpServletRequest request, HttpServletResponse response)
		    throws SQLException, ServletException, IOException {
		        String email = (request.getParameter("email"));
		        Customer existingCustomer = customerDao.selectCustomer(email);
		        RequestDispatcher dispatcher = request.getRequestDispatcher("customer-form.jsp");
		        request.setAttribute("customer", existingCustomer);
		        dispatcher.forward(request, response);

		    }
	private void updateCustomer(HttpServletRequest request, HttpServletResponse response)
		    throws SQLException, IOException {
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String Address = request.getParameter("Address");
		String City = request.getParameter("City");
		String State = request.getParameter("State");
		String Email = request.getParameter("Email");

		        Customer customer = new Customer(firstName, lastName, Address, City,State, Email);
		        customerDao.updateCustomer(customer);
		        response.sendRedirect("list");
	 }
}
