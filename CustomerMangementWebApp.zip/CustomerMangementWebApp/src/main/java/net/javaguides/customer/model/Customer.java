package net.javaguides.customer.model;

public class Customer {

	String firstName;
	String lastName;
	String Address;
	String City;
	String State;
	String Email;
	double Phone;
	
	public Customer() {
		
	}
	public Customer(String v1,String v2,String v3,String v4,String v5, String v6,double v7)
	{
		firstName=v1;
		lastName=v2;
		Address=v3;
		City=v4;
		State=v5;
		Email=v6;
		Phone=v7;
	}
	
	public Customer(String firstName, String lastName, String address, String city, String state, double phone) {
		
		this.firstName = firstName;
		this.lastName = lastName;
		Address = address;
		City = city;
		State = state;
		Phone = phone;
	}
	public Customer(String firstName2, String lastName2, String address2, String city2, String state2, String email2) {
		// TODO Auto-generated constructor stub
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public double getPhone() {
		return Phone;
	}
	public void setPhone(double phone) {
		Phone = phone;
	}
	
}
